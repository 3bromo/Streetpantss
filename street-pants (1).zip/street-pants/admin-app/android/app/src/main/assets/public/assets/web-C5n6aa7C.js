import{W as n}from"./index-zAA_3k-W.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
